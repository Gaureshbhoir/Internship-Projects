<!DOCTYPE html>
<html>
<head>
    <title>Doctor Details</title>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables CSS and JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap for Buttons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <h2 class="text-center my-4">Patient Details</h2>
    <?php
    require('connect.php');
$sql = "SELECT patient_id, name, gender, dob, contact_number, address, blood_group FROM patients";
$result = mysqli_query($conn, $sql);

// Check for SQL error
if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
    ?>

    <div class="container">
        <table id="doctorTable" class="display table table-bordered">
            <thead>
                <tr>
                    <th>patient_id</th>
                    <th>Name</th>
                    <th>gender </th>
                  <th>DOB</th>
                     <th>contact_number</th>
                     <th>Address</th>
                     <th>Blood_group</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
if ($result && mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>". $row["patient_id"] ."</td>
                                <td>". $row["name"] ."</td>
                                <td>". $row["gender"] ."</td>
                                <td>". $row["dob"] ."</td>
                                <td>". $row["contact_number"] ."</td>

                                 <td>". $row["address"] ."</td>
                                  <td>". $row["blood_group"] ."</td>



                                <td>
                                    <a href='edit_patient.php?id=".$row["patient_id"]."' class='btn btn-warning btn-sm'>Edit</a>
<a href='delete_patient.php?id=".$row["patient_id"]."' class='btn btn-danger btn-sm' onclick=\"return confirm('Are you sure you want to delete this record?');\">Delete</a>
                                </td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('#doctorTable').DataTable();
        });
    </script>
</body>
</html>