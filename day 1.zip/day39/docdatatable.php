<!DOCTYPE html>
<html>
<head>
    <title>Doctor Details</title>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables CSS and JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap for Buttons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <h2 class="text-center my-4">Doctor Details</h2>
    <?php
    require('connect.php');

    $sql = "SELECT doctor_id, name, specialization, contact_number, email FROM doctors";
    $result = mysqli_query($conn, $sql);
    ?>

    <div class="container">
        <table id="doctorTable" class="display table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Specialization</th>
                    <th>Contact No</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>". $row["doctor_id"] ."</td>
                                <td>". $row["name"] ."</td>
                                <td>". $row["specialization"] ."</td>
                                <td>". $row["contact_number"] ."</td>
                                <td>". $row["email"] ."</td>
                                <td>
                                    <a href='edit_doctor.php?id=".$row["doctor_id"]."' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='delete_doctor.php?id=".$row["doctor_id"]."' class='btn btn-danger btn-sm' onclick=\"return confirm('Are you sure you want to delete this record?');\">Delete</a>
                                </td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('#doctorTable').DataTable();
        });
    </script>
</body>
</html>