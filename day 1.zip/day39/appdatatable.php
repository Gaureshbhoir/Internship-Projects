<!DOCTYPE html>
<html>
<head>
    <title>Appointment Details</title>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables CSS and JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap for Buttons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <h2 class="text-center my-4">Appointment Details</h2>
    <?php
    require('connect.php');

    $sql = "SELECT appointment_id, patient_id, doctor_id, appointment_date, status FROM appointments";
    $result = mysqli_query($conn, $sql);
    ?>

    <div class="container">
        <table id="doctorTable" class="display table table-bordered">
            <thead>
                <tr>
                    <th>Appointment_id</th>
                    <th>Patient_id</th>
                    <th>Doctor_id</th>
                    <th>Appointment_date </th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>". $row["appointment_id"] ."</td>
                                <td>". $row["patient_id"] ."</td>
                                <td>". $row["doctor_id"] ."</td>
                                <td>". $row["appointment_date"] ."</td>
                                <td>". $row["status"] ."</td>
                                <td>
                                    <a href='edit_doctor.php?id=".$row["doctor_id"]."' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='delete_doctor.php?id=".$row["doctor_id"]."' class='btn btn-danger btn-sm' onclick=\"return confirm('Are you sure you want to delete this record?');\">Delete</a>
                                </td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('#doctorTable').DataTable();
        });
    </script>
</body>
</html>