<!DOCTYPE html>
<html>
<head>
    <title>Doctor Details</title>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables CSS and JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap for Buttons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <h2 class="text-center my-4">Medical Records Details</h2>
    <?php
    require('connect.php');

    $sql = "SELECT record_id, patient_id, doctor_id, diagnosis, treatment, record_date FROM medical_records";
    $result = mysqli_query($conn, $sql);
    ?>

    <div class="container">
        <table id="doctorTable" class="display table table-bordered">
            <thead>
                <tr>
                    <th>Record_id</th>
                    <th>Patient_id</th>
                    <th>Doctor_id</th>
                    <th>Diagnosis</th>
                    <th>Treatment</th>
                  <th>Record Date</th>

                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>". $row["record_id"] ."</td>
                                <td>". $row["patient_id"] ."</td>
                                <td>". $row["doctor_id"] ."</td>
                                <td>". $row["diagnosis"] ."</td>
                                <td>". $row["treatment"] ."</td>
                                <td>". $row["record_date"] ."</td>


                                <td>
                                    <a href='edit_doctor.php?id=".$row["doctor_id"]."' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='delete_doctor.php?id=".$row["doctor_id"]."' class='btn btn-danger btn-sm' onclick=\"return confirm('Are you sure you want to delete this record?');\">Delete</a>
                                </td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('#doctorTable').DataTable();
        });
    </script>
</body>
</html>