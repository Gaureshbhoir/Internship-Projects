<?php
$a=10;
$b=20;
echo($a+b);
?>