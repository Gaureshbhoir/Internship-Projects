<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "v2v";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, address, phone, email, course, gender FROM registration";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["name"].  " - Phone: " . $row["phone"]. " - Address: " . $row["address"]. " - Course: " . $row["course"]. " - Gender: " . $row["gender"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
