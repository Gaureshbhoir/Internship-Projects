<?php include('connect.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Bill</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-4">
    <h2>Add Bill</h2>
    <form method="POST" class="border p-4 rounded">
        <div class="mb-3">
            <label>Patient ID:</label>
            <input type="number" name="patient_id" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Total Amount:</label>
            <input type="number" step="0.01" name="total_amount" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Payment Status:</label>
            <select name="payment_status" class="form-control">
                <option value="Pending">Pending</option>
                <option value="Paid">Paid</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Bill Date:</label>
            <input type="date" name="bill_date" class="form-control" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Add Bill</button>
    </form>

<?php
if (isset($_POST['submit'])) {
    $patient_id = $_POST['patient_id'];
    $total_amount = $_POST['total_amount'];
    $payment_status = $_POST['payment_status'];
    $bill_date = $_POST['bill_date'];

    $sql = "INSERT INTO Billing (patient_id, total_amount, payment_status, bill_date)
            VALUES ('$patient_id', '$total_amount', '$payment_status', '$bill_date')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert alert-success mt-3'>Bill added successfully!</div>";
    } else {
        echo "<div class='alert alert-danger mt-3'>Error: " . $conn->error . "</div>";
    }
}
?>
</body>
</html>