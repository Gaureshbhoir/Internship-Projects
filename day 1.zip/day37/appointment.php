<!DOCTYPE html>
<html>
<head>
    <title>Add Appointment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
    <div class="card p-4">
        <h3 class="mb-3">Add Appointment</h3>
        <form method="POST">
            <div class="mb-3">
                <label>Patient</label>
                <select name="patient_id" class="form-select" required>
                    <option value="">Select Patient</option>
                    <?php
                    $conn = new mysqli("localhost","root","","hospital_management");
                    $patients = $conn->query("SELECT patient_id, name FROM Patients");
                    while($p = $patients->fetch_assoc()){
                        echo "<option value='{$p['patient_id']}'>{$p['name']} (ID: {$p['patient_id']})</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label>Doctor</label>
                <select name="doctor_id" class="form-select" required>
                    <option value="">Select Doctor</option>
                    <?php
                    $doctors = $conn->query("SELECT doctor_id, name FROM Doctors");
                    while($d = $doctors->fetch_assoc()){
                        echo "<option value='{$d['doctor_id']}'>{$d['name']} (ID: {$d['doctor_id']})</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3"><label>Appointment Date</label><input type="datetime-local" name="appointment_date" class="form-control" required></div>
            <div class="mb-3">
                <label>Status</label>
                <select name="status" class="form-select">
                    <option>Scheduled</option>
                    <option>Completed</option>
                    <option>Cancelled</option>
                </select>
            </div>
            <button class="btn btn-primary" name="submit">Add Appointment</button>
        </form>
        <?php
        if(isset($_POST['submit'])){
            $pid=$_POST['patient_id'];
            $did=$_POST['doctor_id'];
            $date=$_POST['appointment_date'];
            $status=$_POST['status'];

            $sql="INSERT INTO Appointments(patient_id,doctor_id,appointment_date,status) 
                  VALUES('$pid','$did','$date','$status')";

            if($conn->query($sql)){
                echo "<div class='alert alert-success mt-3'>Appointment added successfully!</div>";
            }else{
                echo "<div class='alert alert-danger mt-3'>Error: ".$conn->error."</div>";
            }
        }
        $conn->close();
        ?>
    </div>
</div>
</body>
</html>