<?php
$server="localhost";
$user="root";
$password="";
$db="v2v";
$conn = mysqli_connect($server, $user, $password,$db);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$name=$_GET['fname'];
$phone=$_GET['phone'];
$email=$_GET['email'];
$Address=$_GET['address'];
$Gender=$_GET['gender'];
if(!isset($_GET['course'])) {
  echo"Course is required!";
  exit;
}
$course=$_GET['course'];


$sql = "INSERT INTO registration(Name,Address,Phone,Email,gender,Course)
VALUES ( '$name', '$Address','$phone','$email','$Gender','$course')";
if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>